package com.example.administrator.myapplication;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView.OnItemSelectedListener;
import java.util.GregorianCalendar;

//public class MainActivity extends ActionBarActivity{
public class MainActivity extends ActionBarActivity implements OnItemSelectedListener{

    String KBK_st = "", GOD_string = "", st_KoAP_string = "", kod_ist_dohod = "";
    int GOD;

    char doc_sub_simvol1 = '6';
    char doc_sub_simvol2 = '0';
    char doc_sub_simvol3 = '1';

    Spinner GOD_Spinner, st_KoAP, doc_Spinner, sub_Spinner;
    TextView KBK_TextView, nom_Post_TextView, UIN_TextView, Nomer_EditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Nomer_EditText = (TextView)findViewById(R.id.editText);
        UIN_TextView = (TextView)findViewById(R.id.textView4);

        // Текст следующего кода мне малопонятен )
        setContentView(R.layout.activity_main);
        // получаем элемент TextView
        KBK_TextView = (TextView)findViewById(R.id.textView6);

        //Установка слушателя для выпадающего списка статей КоАП
        st_KoAP = (Spinner) findViewById(R.id.spinner);
        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемента spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.st_koap, android.R.layout.simple_spinner_item);
        // Определяем разметку для использования при выборе элемента
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Применяем адаптер к элементу spinner
        st_KoAP.setAdapter(adapter);
        st_KoAP.setOnItemSelectedListener(this);

        //Установка слушателя для выпадающего списка годов
        GOD_Spinner = (Spinner) findViewById(R.id.spinner2);
        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемента spinner
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
                R.array.god_kalen, android.R.layout.simple_spinner_item);
        // Определяем разметку для использования при выборе элемента
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Применяем адаптер к элементу spinner
        GOD_Spinner.setAdapter(adapter1);
        GOD_Spinner.setOnItemSelectedListener(this);

        //Установка слушателя для выпадающего списка вида документа
        doc_Spinner = (Spinner) findViewById(R.id.spinner3);
        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемента spinner
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,
                R.array.vid_doc, android.R.layout.simple_spinner_item);
        // Определяем разметку для использования при выборе элемента
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Применяем адаптер к элементу spinner
        doc_Spinner.setAdapter(adapter3);
        doc_Spinner.setOnItemSelectedListener(this);


        //Установка слушателя для выпадающего списка субъектов
        sub_Spinner = (Spinner) findViewById(R.id.spinner4);
        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемента spinner
        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this,
                R.array.sub_spisok, android.R.layout.simple_spinner_item);
        // Определяем разметку для использования при выборе элемента
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Применяем адаптер к элементу spinner
        sub_Spinner.setAdapter(adapter4);
        sub_Spinner.setOnItemSelectedListener(this);


        // Узнаем текущий календарный год
        GregorianCalendar calendar = new GregorianCalendar();
        GOD = calendar.get(GregorianCalendar.YEAR);
        // Установим текущий календарный год в выпадающем списке
        GOD_string = GOD_Spinner.getSelectedItem().toString();
        if (GOD > 2013 & GOD < 2025) GOD_Spinner.setSelection(GOD-2014);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    public void onClick(View view) {

        // Определим номер постановления
        UIN_TextView = (TextView)findViewById(R.id.textView4);
        Nomer_EditText = (TextView)findViewById(R.id.editText);
        int dlina = Nomer_EditText.getText().length();
        // Проверим, был ли введен номер постановления
        if (dlina == 0) {
            // Номер постановления не вводился, т.к. длина его поля нулевая
            UIN_TextView.setText("УИН->");
            Context context = getApplicationContext();
            Toast vvedi_N_post = Toast.makeText(context, "Введите № постановления!", Toast.LENGTH_SHORT);
            vvedi_N_post.show();
        }
        else {

            // Преобразуем номер постановления в 9-символьную строку
            char Nomer_Post_char[] = new char [6];
            for (int i = 5; i >= 0; i--) Nomer_Post_char[i] = '0';
            String Nomer_Post_string = Nomer_EditText.getText().toString(); // приводим к типу String
            int l=dlina-1;
            for (int i = 5; i >= 6-dlina; i--) Nomer_Post_char[i] = Nomer_Post_string.charAt(l--);
            String Nomer_Post_string_6 = String.valueOf(Nomer_Post_char, 0, 6);

            // Определим код источника дохода
            st_KoAP = (Spinner) findViewById(R.id.spinner);
            st_KoAP_string = st_KoAP.getSelectedItem().toString();

            if(st_KoAP_string.equals("ст. 6.24")) {
                kod_ist_dohod = "44";
                KBK_st = "106 1 16 90040 04 6000 140";
            }
            if(st_KoAP_string.equals("ст. 6.25")) {
                kod_ist_dohod = "44";
                KBK_st = "106 1 16 90040 04 6000 140";
            }
            if(st_KoAP_string.equals("ст. 8.22")) {
                kod_ist_dohod = "35";
                KBK_st = "106 1 16 25050 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 8.23")) {
                kod_ist_dohod = "35";
                KBK_st = "106 1 16 25050 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 11.14.2")) {
                kod_ist_dohod = "40";
                KBK_st = "106 1 16 30020 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 11.22")) {
                kod_ist_dohod = "32";
                KBK_st = "106 1 16 90010 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 11.23")) {
                kod_ist_dohod = "28";
                KBK_st = "106 1 16 29000 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 11.29")) {
                kod_ist_dohod = "28";
                KBK_st = "106 1 16 29000 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 11.31")) {
                kod_ist_dohod = "33";
                KBK_st = "106 1 16 48000 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 11.33")) {
                kod_ist_dohod = "40";
                KBK_st = "106 1 16 30020 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 12.21.1")) {
                kod_ist_dohod = "29";
                KBK_st = "106 1 16 30011 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 12.21.2")) {
                kod_ist_dohod = "28";
                KBK_st = "106 1 16 29000 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 12.23")) {
                kod_ist_dohod = "40";
                KBK_st = "106 1 16 30020 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 12.31.1")) {
                kod_ist_dohod = "40";
                KBK_st = "106 1 16 30020 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 14.1")) {
                kod_ist_dohod = "44";
                KBK_st = "106 1 16 90040 04 6000 140";
            }
            if(st_KoAP_string.equals("ст. 14.1.2")) {
                kod_ist_dohod = "44";
                KBK_st = "106 1 16 90040 04 6000 140";
            }
            if(st_KoAP_string.equals("ст. 14.43")) {
                kod_ist_dohod = "23";
                KBK_st = "106 1 16 01000 01 6000 140";
            }
            if(st_KoAP_string.equals("ст. 19.4")) {
                kod_ist_dohod = "44";
                KBK_st = "106 1 16 90040 04 6000 140";
            }
            if(st_KoAP_string.equals("ст. 19.5")) {
                kod_ist_dohod = "44";
                KBK_st = "106 1 16 90040 04 6000 140";
            }
            if(st_KoAP_string.equals("ст. 19.7")) {
                kod_ist_dohod = "44";
                KBK_st = "106 1 16 90040 04 6000 140";
            }
            if(st_KoAP_string.equals("ст. 19.7.5-1")) {
                kod_ist_dohod = "44";
                KBK_st = "106 1 16 90040 04 6000 140";
            }
            if(st_KoAP_string.equals("ст. 19.20")) {
                kod_ist_dohod = "44";
                KBK_st = "106 1 16 90040 04 6000 140";
            }
            if(st_KoAP_string.equals("ст. 20.25")) {
                kod_ist_dohod = "42";
                KBK_st = "106 1 16 43000 01 6000 140";
            }

            // Определим последние 2-е цифры выбранного календарного года
            GOD_Spinner = (Spinner) findViewById(R.id.spinner2);
            GOD_string = GOD_Spinner.getSelectedItem().toString();
            char GOD_simvol1 =  GOD_string.charAt(2); // 3 цифра года
            char GOD_simvol2 =  GOD_string.charAt(3); // 4 цифра года


            // Создадим 2-а массива - символьный и цифровой, состоящих из первых 19 разрядов УИН
            String UIN_19_string = "10636"+kod_ist_dohod+"2"+GOD_simvol1+GOD_simvol2+doc_sub_simvol1+doc_sub_simvol2+doc_sub_simvol3+Nomer_Post_string_6;
            char UIN_simvol[] = new char [19];
            int UIN[] = new int [20];
            for (int i=0; i <19; i++) {
                UIN_simvol[i] = UIN_19_string.charAt(i);
                UIN[i] = Character.getNumericValue(UIN_simvol[i]);
            }

            // Рассчитываем сумму произведений значений разрядов УИН
            // на весовые параметры от 1 до 10, начиная с 1.
            int summ_proisv;
            summ_proisv = UIN[0] * 1 + UIN[1] * 2 + UIN[2] * 3;
            summ_proisv = summ_proisv + UIN[3] * 4 + UIN[4] * 5;
            summ_proisv = summ_proisv + UIN[5] * 6 + UIN[6] * 7;
            summ_proisv = summ_proisv + UIN[7] * 8 + UIN[8] * 9 + UIN[9] * 10;
            summ_proisv = summ_proisv + UIN[10] * 1 + UIN[11] * 2;
            summ_proisv = summ_proisv + UIN[12] * 3 + UIN[13] * 4;
            summ_proisv = summ_proisv + UIN[14] * 5 + UIN[15] * 6;
            summ_proisv = summ_proisv + UIN[16] * 7 + UIN[17] * 8;
            summ_proisv = summ_proisv + UIN[18] * 9;

            // Рассчитываем контрольный разряд УИН
            UIN[19] =  summ_proisv % 11;

            // Если контрольный разряд УИН равен 10, заново
            // рассчитываем сумму произведений значений разрядов УИН
            // на весовые параметры от 1 до 10, но уже начиная с 3.
            if (UIN[19] == 10) {
                summ_proisv = UIN[0] * 3 + UIN[1] * 4 + UIN[2] * 5;
                summ_proisv = summ_proisv + UIN[3] * 6 + UIN[4] * 7;
                summ_proisv = summ_proisv + UIN[5] * 8 + UIN[6] * 9;
                summ_proisv = summ_proisv + UIN[7] * 10 + UIN[8] * 1 + UIN[9] * 2;
                summ_proisv = summ_proisv + UIN[10] * 3 + UIN[11] * 4;
                summ_proisv = summ_proisv + UIN[12] * 5 + UIN[13] * 6;
                summ_proisv = summ_proisv + UIN[14] * 7 + UIN[15] * 8;
                summ_proisv = summ_proisv + UIN[16] * 9 + UIN[17] * 10;
                summ_proisv = summ_proisv + UIN[18] * 1;

                // Заново рассчитываем контрольный разряд УИН
                UIN[19] =  summ_proisv % 11;
            }
            // Если контрольный разряд УИН снова равен 10, присваеваем ему значение 0
            if (UIN[19] == 10) UIN[19] = 0;

            // Выведем УИН на экран
            UIN_TextView.setText("УИН-> "+"106 36"+" "+kod_ist_dohod+" 2"+GOD_simvol1+GOD_simvol2+" "+doc_sub_simvol1+doc_sub_simvol2+doc_sub_simvol3+Nomer_Post_string_6 +" "+UIN[19]);
            KBK_TextView.setText("КБК: " + KBK_st);
        }
    }
    // Кнопка ВЫХОД
    public void onClick1(View view) {
        System.exit(0); //Выход их программы
        // finish(); // Завершить работу окна
        // или
        // this.finish();
    }
    // Кнопка СБРОС
    public void onClick2(View view) {
        UIN_TextView = (TextView)findViewById(R.id.textView4);
        UIN_TextView.setText("УИН->");
        Nomer_EditText = (TextView)findViewById(R.id.editText);
        Nomer_EditText.setText(null);

        doc_sub_simvol1 = '6';
        doc_sub_simvol2 = '0';
        doc_sub_simvol3 = '1';
        nom_Post_TextView = (TextView)findViewById(R.id.textView);
        nom_Post_TextView.setText("№: "+doc_sub_simvol1+doc_sub_simvol2+doc_sub_simvol3);

        // Установим текущий календарный год в выпадающем списке
        GOD_Spinner = (Spinner) findViewById(R.id.spinner2);
        if (GOD > 2013 & GOD < 2025) GOD_Spinner.setSelection(GOD-2014);
        st_KoAP = (Spinner)findViewById(R.id.spinner);
        st_KoAP.setSelection(0);

        doc_Spinner = (Spinner) findViewById(R.id.spinner3);
        doc_Spinner.setSelection(0);

        sub_Spinner = (Spinner) findViewById(R.id.spinner4);
        sub_Spinner.setSelection(0);

        Context context = getApplicationContext();
        Toast vvedi_N_post = Toast.makeText(context, "Все значения сброшены!", Toast.LENGTH_SHORT);
        vvedi_N_post.show();
    }

    public void onItemSelected (AdapterView<?> parent, View view, int pos, long id) {
        // Получаем выбранный объект
        Object item = parent.getItemAtPosition(pos);
        // st_KoAP_string - содержит выбранное в выпадающем списке значение
        // статьи КоАП или года, в случае изменения одного из этих параметров
        st_KoAP_string = item.toString();

        if(st_KoAP_string.equals("ст. 6.24")) {
            kod_ist_dohod = "44";
            KBK_st = "106 1 16 90040 04 6000 140";
        }
        if(st_KoAP_string.equals("ст. 6.25")) {
            kod_ist_dohod = "44";
            KBK_st = "106 1 16 90040 04 6000 140";
        }
        if(st_KoAP_string.equals("ст. 8.22")) {
            kod_ist_dohod = "35";
            KBK_st = "106 1 16 25050 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 8.23")) {
            kod_ist_dohod = "35";
            KBK_st = "106 1 16 25050 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 11.14.2")) {
            kod_ist_dohod = "40";
            KBK_st = "106 1 16 30020 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 11.22")) {
            kod_ist_dohod = "32";
            KBK_st = "106 1 16 90010 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 11.23")) {
            kod_ist_dohod = "28";
            KBK_st = "106 1 16 29000 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 11.29")) {
            kod_ist_dohod = "28";
            KBK_st = "106 1 16 29000 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 11.31")) {
            kod_ist_dohod = "33";
            KBK_st = "106 1 16 48000 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 11.33")) {
            kod_ist_dohod = "40";
            KBK_st = "106 1 16 30020 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 12.21.1")) {
            kod_ist_dohod = "29";
            KBK_st = "106 1 16 30011 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 12.21.2")) {
            kod_ist_dohod = "28";
            KBK_st = "106 1 16 29000 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 12.23")) {
            kod_ist_dohod = "40";
            KBK_st = "106 1 16 30020 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 12.31.1")) {
            kod_ist_dohod = "40";
            KBK_st = "106 1 16 30020 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 14.1")) {
            kod_ist_dohod = "44";
            KBK_st = "106 1 16 90040 04 6000 140";
        }
        if(st_KoAP_string.equals("ст. 14.1.2")) {
            kod_ist_dohod = "44";
            KBK_st = "106 1 16 90040 04 6000 140";
        }
        if(st_KoAP_string.equals("ст. 14.43")) {
            kod_ist_dohod = "23";
            KBK_st = "106 1 16 01000 01 6000 140";
        }
        if(st_KoAP_string.equals("ст. 19.4")) {
            kod_ist_dohod = "44";
            KBK_st = "106 1 16 90040 04 6000 140";
        }
        if(st_KoAP_string.equals("ст. 19.5")) {
            kod_ist_dohod = "44";
            KBK_st = "106 1 16 90040 04 6000 140";
        }
        if(st_KoAP_string.equals("ст. 19.7")) {
            kod_ist_dohod = "44";
            KBK_st = "106 1 16 90040 04 6000 140";
        }
        if(st_KoAP_string.equals("ст. 19.7.5-1")) {
            kod_ist_dohod = "44";
            KBK_st = "106 1 16 90040 04 6000 140";
        }
        if(st_KoAP_string.equals("ст. 19.20")) {
            kod_ist_dohod = "44";
            KBK_st = "106 1 16 90040 04 6000 140";
        }
        if(st_KoAP_string.equals("ст. 20.25")) {
            kod_ist_dohod = "42";
            KBK_st = "106 1 16 43000 01 6000 140";
        }

        if(st_KoAP_string.equals("Постановление")) {
            doc_sub_simvol1 = '6';
            nom_Post_TextView = (TextView)findViewById(R.id.textView);
            nom_Post_TextView.setText("№: "+doc_sub_simvol1+doc_sub_simvol2+doc_sub_simvol3);
        }
        if(st_KoAP_string.equals("Протокол")) {
            doc_sub_simvol1 = '7';
            nom_Post_TextView = (TextView)findViewById(R.id.textView);
            nom_Post_TextView.setText("№: "+doc_sub_simvol1+doc_sub_simvol2+doc_sub_simvol3);
        }
        if(st_KoAP_string.equals("Гражданин/водитель")) {
            doc_sub_simvol3 = '1';
            nom_Post_TextView = (TextView)findViewById(R.id.textView);
            nom_Post_TextView.setText("№: "+doc_sub_simvol1+doc_sub_simvol2+doc_sub_simvol3);
        }
        if(st_KoAP_string.equals("ИП")) {
            doc_sub_simvol3 = '2';
            nom_Post_TextView = (TextView)findViewById(R.id.textView);
            nom_Post_TextView.setText("№: "+doc_sub_simvol1+doc_sub_simvol2+doc_sub_simvol3);
        }
        if(st_KoAP_string.equals("Должностное лицо")) {
            doc_sub_simvol3 = '3';
            nom_Post_TextView = (TextView)findViewById(R.id.textView);
            nom_Post_TextView.setText("№: "+doc_sub_simvol1+doc_sub_simvol2+doc_sub_simvol3);
        }
        if(st_KoAP_string.equals("Юридическое лицо")) {
            doc_sub_simvol3 = '4';
            nom_Post_TextView = (TextView)findViewById(R.id.textView);
            nom_Post_TextView.setText("№: "+doc_sub_simvol1+doc_sub_simvol2+doc_sub_simvol3);
        }

        // Тест: выведем на экран всплывающее сообщение с измененным значением st_KoAP_string (ст.КоАП или Год)
        //Context context = getApplicationContext();
        //Toast vvedi_N_post = Toast.makeText(context, st_KoAP_string, Toast.LENGTH_SHORT);
        //vvedi_N_post.show();

        KBK_TextView.setText("КБК: " + KBK_st);
        UIN_TextView.setText("УИН->");
        st_KoAP_string = "";
    }
    public void onNothingSelected(AdapterView<?> parent) {
        // Обработка события
    }
}
